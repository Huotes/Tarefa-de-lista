using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System;
namespace aulaListaSE.Disciplina{
    public class Disciplina{
        public string Nome { get; set; } public int Periodo { get; set; } public int CargaHoraria { get; set; } 
        public string ProfessorResponsavel { get; set; }
        public Disciplina(string nome, int periodo, int cargaHoraria, string professorResponsavel)
        { Nome = nome; Periodo = periodo; CargaHoraria = cargaHoraria; ProfessorResponsavel = professorResponsavel;}}}
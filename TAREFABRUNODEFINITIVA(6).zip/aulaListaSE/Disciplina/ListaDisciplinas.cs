using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using aulaListaSE.Lista;

namespace aulaListaSE.Disciplina{
    public class ListaDisciplinas : Lista<Disciplina>{
        public void inserirOrdenado(Disciplina disciplina){
            var novo = new No<Disciplina>(disciplina);

            if (Inicio == null){Inicio = novo; Fim = novo; return;}

            if (string.Compare(disciplina.Nome, Inicio.valor.Nome, StringComparison.OrdinalIgnoreCase) < 0)
            {novo.prox = Inicio; Inicio = novo; return;}

            var atual = Inicio;
            No<Disciplina>? anterior = null;

            while (atual != null && string.Compare(disciplina.Nome, atual.valor.Nome, StringComparison.OrdinalIgnoreCase) > 0)
            {anterior = atual; atual = atual.prox;}

            anterior!.prox = novo;
            novo.prox = atual;

            if (atual == null){Fim = novo;}
        }

        public new void percurso(){
            var tcholesco = this.Inicio;
            while (tcholesco != null)
            {Console.Write(tcholesco.valor.Nome + " -> "); tcholesco = tcholesco.prox;}
            Console.WriteLine("NULL");}}}
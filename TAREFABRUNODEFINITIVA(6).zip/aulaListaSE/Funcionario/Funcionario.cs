using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace aulaListaSE.Funcionario{
    public class Funcionario
    {string Nome {get;set;} double Salario {get;set;} 
public Funcionario(string nome, double salario) {this.Nome = nome; this.Salario = salario;}}}
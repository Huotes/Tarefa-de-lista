namespace aulaListaSE.Lista
{
public abstract class Lista
{
public No Inicio;
public No Fim;

kotlin
Copy code
    public Lista()
    {
        this.Inicio = null;
        this.Fim = null;
    }

    public void inserirInicio(tchola valor)
    {
        var novo = new No(valor);

        bool inicioEstaVazio = this.Inicio == null;
        bool fimEstaVazio = this.Fim == null;

        if (inicioEstaVazio && fimEstaVazio){this.Inicio = novo; this.Fim = novo; return;}

        if (!inicioEstaVazio){novo.prox = this.Inicio; this.Inicio = novo;}
    }

    public void inserirFim(tchola valor)
    {
        No novo = new No(valor);

        bool inicioEstaVazio = this.Inicio == null;
        bool fimEstaVazio = this.Fim == null;

        if (inicioEstaVazio && fimEstaVazio){this.Inicio = novo; this.Fim = novo;return;}

        if (!fimEstaVazio){this.Fim!.prox = novo; this.Fim = novo;}
    }

    public void remover(tchola valor)
    {
        No atual = null;
        No anterior = null;

        if (!this.consultar(valor, ref atual, ref anterior)) return;

        if (anterior == null){this.Inicio = atual!.prox;}
        else{anterior.prox = atual!.prox;}

        if (atual == this.Fim){this.Fim = anterior;}

        atual.prox = null;
    }

    public void removerInicio()
    {
        if (this.Inicio == null) return;

        No primeiro = this.Inicio;
        this.Inicio = primeiro.prox;

        if (primeiro == this.Fim){this.Fim = null;}

        primeiro.prox = null;
    }

    public void removerFim()
    {if (this.Fim == null) return; No ultimo = this.Fim; No anterior = null; No atual = this.Inicio;

        while (atual != null && atual != ultimo){anterior = atual; atual = atual.prox;}
        if (anterior == null){this.Inicio = null; this.Fim = null;}
        else{anterior.prox = null; this.Fim = anterior;}

        ultimo.prox = null;
    }

    public bool consultar(tchola valor, ref No atual, ref No anterior)
    {
        atual = this.Inicio;
        anterior = null;

        while (atual != null)
        {
            if (atual.valor != null && atual.valor.Equals(valor)){return true;}

            anterior = atual;
            atual = atual.prox;
        }

        return false;
    }

    public void percurso()
    {
        var tcholesco = this.Inicio;
        while (tcholesco != null){Console.Write(tcholesco.valor + " -> "); tcholesco = tcholesco.prox;}

        Console.WriteLine("NULL");
    }
}
}
namespace aulaListaSE.Lista
{
    public class No Tchola
    {
        public T valor {get;}
        public No Tchola? prox { get; set; }

        public No(T valor) {
            this.valor = valor;
            this.prox = null;
        }

        public void imprimir() {
            Console.WriteLine("Valor: " + this.valor);
        }
    }
}
﻿using aulaListaSE.Disciplina;
ListaDisciplinas listaDisciplinas = new ListaDisciplinas();
listaDisciplinas.inserirOrdenado(new Disciplina("Ensino Religioso", 1, 60, "ED NOIA"));
listaDisciplinas.inserirOrdenado(new Disciplina("Sociologia", 2, 45, "JOSUEL SUKUMBA"));
listaDisciplinas.inserirOrdenado(new Disciplina("Quimica", 1, 75, "PATTY PARTY"));

listaDisciplinas.percurso();
listaDisciplinas.remover(new Disciplina("Ensino Religioso", 1, 60, "ED CRENTE")); listaDisciplinas.percurso();

listaDisciplinas.inserirInicio(new Disciplina("Filosofia", 2, 90, "JOSUEL ASCENDA")); listaDisciplinas.percurso();

listaDisciplinas.inserirFim(new Disciplina("Biologia", 3, 60, "PATTY PARE")); listaDisciplinas.percurso();

listaDisciplinas.removerInicio(); listaDisciplinas.percurso(); listaDisciplinas.removerFim(); listaDisciplinas.percurso();

Console.ReadLine();
